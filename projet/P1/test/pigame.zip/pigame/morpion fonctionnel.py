# Créé par yanis.boulogne, le 16/09/2021 en Python 3.7
import morpion_visuel.py
import pygame