# Créé par yanis.boulogne, le 16/09/2021 en Python 3.7
import pygame

MARRON = (90,40,0)
VERT = (100,100,50)
BLEU = (50,50,100)
JAUNE =(218, 248, 125)
ROUGE = (199, 44, 72)
pos = (0,0)
JOUEUR = 1
x = 600
y = 600


main = pygame.display.set_mode((600,600))
run = True
def plateau(x,y):
    '''
    permet de creer le plateau à partir des dimmension de l'écran
    '''
    L = 0
    main.fill(MARRON)
    for i in range(2):
        L = L + x/3
        pygame.draw.line(main, (VERT),(L,0),(L,x),10)
        pygame.draw.line(main, (VERT),(0,L),(x,L),10)
    pygame.display.flip()
    return

def cercle():
    pos = pygame.mouse.get_pos()
    pygame.draw.circle(main, (BLEU), ((x//3) * (pos[0]//300) + ((x//3)//2) ,(x//3) * (pos[1]//300) + ((x//3)//2)), ((x//3)//2), 5)
    return

def croix():
    pos = pygame.mouse.get_pos()
    pygame.draw.line(main, (JAUNE), ((x//3) * (pos[0]//300), 300 * (pos[1]//300)), (300 * (pos[0]//300) + 300, 300 * (pos[1]//300) + 300), 5)
    pygame.draw.line(main, (JAUNE), ((x//3) * (pos[0]//300), 300 * (pos[1]//300) + 300), ((x//3) * (pos[0]//300) + (x//3), 300 * (pos[1]//300) ), 5)
    return

while run :
    for event in pygame.event.get():
        if event.type == pygame.QUIT :
            run = False

        if JOUEUR == 1:
            if event.type == pygame.MOUSEBUTTONDOWN:
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    pos = pygame.mouse.get_pos()
                    croix()
                    JOUEUR = 2

        else:
            if event.type == pygame.MOUSEBUTTONDOWN:
                if pygame.mouse.get_pressed() == (1, 0, 0):
                    pos = pygame.mouse.get_pos()
                    cercle()
                    JOUEUR = 1

        if event.type == pygame.KEYDOWN :
            if event.key == pygame.K_RETURN :
                plateau(x,y)


    pygame.display.flip()
pygame.quit()
