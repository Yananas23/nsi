# Créé par Yanis Boulogne, le 20/10/2021 en Python 3.7
import pygame
import morpion_V14
import victoire
